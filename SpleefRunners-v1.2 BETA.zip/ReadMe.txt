
   _____       _            __   _____                                 
  / ____|     | |          / _| |  __ \                                
 | (___  _ __ | | ___  ___| |_  | |__) |   _ _ __  _ __   ___ _ __ ___ 
  \___ \| '_ \| |/ _ \/ _ \  _| |  _  / | | | '_ \| '_ \ / _ \ '__/ __|
  ____) | |_) | |  __/  __/ |   | | \ \ |_| | | | | | | |  __/ |  \__ \
 |_____/| .__/|_|\___|\___|_|   |_|  \_\__,_|_| |_|_| |_|\___|_|  |___/
        | |                                                            
        |_|                                                            

		
Thank you for downloading our map!

Setup:
- 1. Copy and paste the map folder to your minecraft saves folder.
- 2. Map has been installed succesfully.
- 3. If you are in the map, first of all you need to reset the game.
- 4. After that, you can play! ENJOY :)


You can support our work with a diamond on PlanetMinecraft.com
If you are recording, please send the clip to scrubloverz@gmail.com
